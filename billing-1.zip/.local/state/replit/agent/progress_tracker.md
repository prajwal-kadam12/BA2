[x] 1. Install the required packages
[x] 2. Restart the workflow to see if the project is working
[x] 3. Verify the project is working using the feedback tool
[x] 4. Inform user the import is completed and they can start building, mark the import as completed using the complete_project_import tool
[x] 5. Fixed issue where clicking on a bill only opened the detail view instead of the edit form. Now, clicking a bill fetches details and opens the edit form directly.
[x] 6. Fixed cross-env not found error and configured workflow with webview output
[x] 7. Commented out pagination buttons in QuoteDetailPanel.tsx
[x] 8. Commented out pagination buttons in sales-orders.tsx
[x] 9. Set min-width to 40% for the side panel in delivery-challans.tsx
[x] 10. Set min-width to 40% for the side panel in credit-notes.tsx
[x] 11. Improved e-Way Bill form UI to be simpler and more attractive
[x] 12. Positioned pagination component at the bottom with improved visual styling
[x] 13. Re-installed cross-env and verified application is running successfully
