export { default } from '@/pages/customers';
