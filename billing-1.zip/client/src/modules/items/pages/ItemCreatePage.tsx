export { default } from '@/pages/products-create';
