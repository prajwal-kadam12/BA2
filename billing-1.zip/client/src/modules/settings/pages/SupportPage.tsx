export { default } from '@/pages/support';
