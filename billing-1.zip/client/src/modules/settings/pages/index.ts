export { default as SettingsPage } from './SettingsPage';
export { default as SupportPage } from './SupportPage';
