export { default } from '@/pages/expenses';
