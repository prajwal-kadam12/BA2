export { default } from '@/pages/purchase-orders';
