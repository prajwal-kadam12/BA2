export { default } from '@/pages/bills';
