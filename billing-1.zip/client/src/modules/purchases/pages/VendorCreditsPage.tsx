export { default } from '@/pages/vendor-credits';
