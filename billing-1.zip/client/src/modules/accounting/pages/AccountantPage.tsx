export { default } from '@/pages/accountant';
