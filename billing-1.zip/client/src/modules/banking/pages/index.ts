export { default as BankingPage } from './BankingPage';
