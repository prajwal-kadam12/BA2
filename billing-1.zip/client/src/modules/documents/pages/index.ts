export { default as DocumentsPage } from './DocumentsPage';
